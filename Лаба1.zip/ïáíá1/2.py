import turtle

turtle.fd(100)
turtle.left(90)
turtle.fd(100)
turtle.left(90)
turtle.fd(100)
turtle.rt(90)
turtle.fd(100)
turtle.rt(90)
turtle.fd(100)
turtle.exitonclick()