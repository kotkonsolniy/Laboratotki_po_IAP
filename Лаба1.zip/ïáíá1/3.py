import turtle

turtle.shape('turtle')
turtle.fd(100)
turtle.rt(90)
turtle.fd(100)
turtle.rt(90)
turtle.fd(100)
turtle.rt(90)
turtle.fd(100)
turtle.rt(90)
turtle.exitonclick()