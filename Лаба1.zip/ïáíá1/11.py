import turtle
turtle.shape('turtle')
turtle.left(90)
R = 40
def dohvos(R):
    turtle.circle(R)
    turtle.circle(-R)

x=0
while x < 20:
    dohvos(R)
    R += 5
    x += 1
turtle.exitonclick()
