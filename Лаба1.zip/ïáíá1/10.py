import turtle
turtle.shape('turtle')
def flowerkrug(x):
    while x<6:
        turtle.circle(60)
        turtle.left(60)
        x += 1
flowerkrug(0)
turtle.exitonclick()