import turtle
turtle.speed(11)
turtle.shape('turtle')
i = 0
while i < 4:
    turtle.fd(100)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(120)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(140)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(160)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(180)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(200)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(220)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(240)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(260)
    turtle.rt(90)
    i += 1
turtle.lt(135)
turtle.up()
turtle.fd(10)
turtle.down()
turtle.rt(135)
i = 0
while i < 4:
    turtle.fd(280)
    turtle.rt(90)
    i += 1

turtle.exitonclick()