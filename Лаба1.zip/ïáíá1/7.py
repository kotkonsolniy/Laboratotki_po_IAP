import turtle

turtle.speed(1000)
t = 0.1
for i in range(720):
    turtle.fd(t)
    turtle.left(2)
    t += 0.01


turtle.exitonclick()