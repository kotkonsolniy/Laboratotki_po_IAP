import turtle
turtle.speed(11)
turtle.shape('turtle')
turtle.circle(radius=50, steps=3000)
turtle.exitonclick()