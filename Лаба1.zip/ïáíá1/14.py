import turtle
turtle.shape('turtle')

def st(n):
    for i in range(n):
        turtle.right(180 - (180 / n))
        turtle.fd(200)
n = 5
st(n)

turtle.penup()
turtle.goto(250, 0)
turtle.pendown()

n = 11
st(n)

turtle.done()