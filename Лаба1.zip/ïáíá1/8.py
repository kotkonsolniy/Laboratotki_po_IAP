import turtle

turtle.speed(1000)
t = 10
for i in range(50):
    turtle.fd(100 + t)
    turtle.left(90)
    t += 10


turtle.exitonclick()