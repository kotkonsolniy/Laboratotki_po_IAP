import turtle

turtle.shape('turtle')

for i in range(12):
    turtle.left(30)
    turtle.fd(100)
    turtle.clone()
    turtle.goto(0,0)

turtle.exitonclick()