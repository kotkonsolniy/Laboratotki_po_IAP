import turtle
from random import *
turtle.shape('turtle')
for i in range(50):
    turtle.fd(randint(-25, 50))
    turtle.right(randint(-180, 180))

turtle.exitonclick()